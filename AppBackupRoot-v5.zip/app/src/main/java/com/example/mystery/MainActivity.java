package com.example.mystery;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.inputstream.ZipInputStream;
import net.lingala.zip4j.io.outputstream.ZipOutputStream;
import net.lingala.zip4j.model.LocalFileHeader;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.EncryptionMethod;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private static final String BASE = "/sdcard/AppBackup";

    // اسم الملف داخل الـzip -> المجلد الأب الذي يُستخرج إليه
    private static final String[][] SRC = {
            {"data.tar", "/data/data"},
            {"user_de.tar", "/data/user_de/0"},
            {"ext_data.tar", "/sdcard/Android/data"},
            {"obb.tar", "/sdcard/Android/obb"}
    };

    /** عنصر في القائمة (تطبيق مثبت أو نسخة محفوظة). */
    private static class AppItem {
        String pkg;
        String label;
        String info;    // سطر المعلومات المختصر
        String detail;  // المعلومات الكاملة (تظهر بالضغط المطول)
        Drawable icon;
        boolean installed;
        boolean frozen;
    }

    // العمليات
    private static final int OP_BACKUP = 0;        // نسخ مع البيانات
    private static final int OP_BACKUP_APK = 1;    // نسخ بدون البيانات
    private static final int OP_RESTORE_FULL = 2;  // استعادة التطبيق + البيانات
    private static final int OP_RESTORE_APK = 3;   // استعادة التطبيق فقط
    private static final int OP_RESTORE_DATA = 4;  // استعادة البيانات فقط

    // عناصر قائمة النقاط الثلاث
    private static final int M_LAUNCH = 1, M_STOP = 2, M_BK_DATA = 3, M_BK_APK = 4,
            M_UNINSTALL = 5, M_UNINSTALL_KEEP = 6, M_FREEZE = 7, M_UNFREEZE = 8,
            M_RS_DATA = 9, M_CLEAR_DATA = 10, M_CLEAR_CACHE = 11, M_SETTINGS = 12,
            M_COPY_PKG = 13, M_RS_FULL = 20, M_RS_APK = 21, M_DEL_BACKUP = 22;

    private ListView listView;
    private TextView txtLog, txtRoot;
    private ScrollView logScroll;
    private Button btnRun, btnTabApps, btnTabBackups;
    private CheckBox chkAll, chkInfo;
    private EditText edtSearch;
    private SharedPreferences prefs;
    private AppAdapter adapter;

    private boolean restoreMode = false;
    private boolean suppress = false;
    private int loadSeq = 0;
    private final List<AppItem> allItems = new ArrayList<>();
    private final List<AppItem> items = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final ExecutorService loader = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("prefs", MODE_PRIVATE);

        listView = findViewById(R.id.listView);
        txtLog = findViewById(R.id.txtLog);
        txtRoot = findViewById(R.id.txtRoot);
        logScroll = findViewById(R.id.logScroll);
        btnRun = findViewById(R.id.btnRun);
        btnTabApps = findViewById(R.id.btnTabApps);
        btnTabBackups = findViewById(R.id.btnTabBackups);
        chkAll = findViewById(R.id.chkAll);
        chkInfo = findViewById(R.id.chkInfo);
        edtSearch = findViewById(R.id.edtSearch);

        chkInfo.setChecked(prefs.getBoolean("showInfo", false));

        adapter = new AppAdapter();
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, pos, id) -> toggle(items.get(pos).pkg));
        listView.setOnItemLongClickListener((parent, view, pos, id) -> {
            showDetail(items.get(pos));
            return true;
        });

        chkAll.setOnCheckedChangeListener((button, checked) -> {
            if (suppress) return;
            // يحدد/يلغي المعروض حالياً (حسب البحث)
            for (AppItem it : items) {
                if (checked) selected.add(it.pkg); else selected.remove(it.pkg);
            }
            adapter.notifyDataSetChanged();
            updateRun();
        });
        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable e) { applyFilter(); }
        });
        chkInfo.setOnCheckedChangeListener((button, checked) -> {
            prefs.edit().putBoolean("showInfo", checked).apply();
            adapter.notifyDataSetChanged();
        });

        btnTabApps.setOnClickListener(v -> { selected.clear(); loadApps(false); });
        btnTabBackups.setOnClickListener(v -> { selected.clear(); loadBackups(false); });
        btnRun.setOnClickListener(v -> runSelected());

        ex.execute(() -> {
            final boolean root = RootShell.hasRoot();
            runOnUiThread(() -> txtRoot.setText(root
                    ? "الروت: متاح ✔"
                    : "الروت: غير متاح ✘ (امنح الصلاحية من Magisk/KernelSU ثم أعد فتح التطبيق)"));
        });

        loadApps(false);
    }

    // ---------- القوائم ----------

    private class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            if (v == null) {
                v = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_app, parent, false);
            }
            final AppItem it = items.get(i);
            ((ImageView) v.findViewById(R.id.imgIcon)).setImageDrawable(it.icon);
            ((TextView) v.findViewById(R.id.txtName)).setText((it.frozen ? "❄ " : "") + it.label);
            v.findViewById(R.id.btnMore).setOnClickListener(x -> showMenu(x, it));
            ((TextView) v.findViewById(R.id.txtPkg)).setText(it.pkg);
            TextView ti = v.findViewById(R.id.txtInfo);
            ti.setText(it.info);
            ti.setVisibility(chkInfo.isChecked() ? View.VISIBLE : View.GONE);
            ((CheckBox) v.findViewById(R.id.chkItem)).setChecked(selected.contains(it.pkg));
            return v;
        }
    }

    private void toggle(String pkg) {
        if (!selected.remove(pkg)) selected.add(pkg);
        adapter.notifyDataSetChanged();
        updateAllBox();
        updateRun();
    }

    private void updateAllBox() {
        suppress = true;
        chkAll.setChecked(!items.isEmpty() && selected.size() == items.size());
        suppress = false;
    }

    private void updateRun() {
        String t = getString(restoreMode ? R.string.do_restore : R.string.do_backup);
        if (!selected.isEmpty()) t += " (" + selected.size() + ")";
        btnRun.setText(t);
    }

    private void showItems(List<AppItem> list) {
        allItems.clear();
        allItems.addAll(list);
        Set<String> present = new HashSet<>();
        for (AppItem it : list) present.add(it.pkg);
        selected.retainAll(present);
        applyFilter();
    }

    private void applyFilter() {
        String q = edtSearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        items.clear();
        for (AppItem it : allItems) {
            if (q.isEmpty()
                    || it.label.toLowerCase(Locale.ROOT).contains(q)
                    || it.pkg.toLowerCase(Locale.ROOT).contains(q)) {
                items.add(it);
            }
        }
        adapter.notifyDataSetChanged();
        updateAllBox();
        updateRun();
    }

    private void reload() {
        if (restoreMode) loadBackups(true); else loadApps(true);
    }

    private void showDetail(AppItem it) {
        new AlertDialog.Builder(this)
                .setTitle(it.label)
                .setIcon(it.icon)
                .setMessage(it.detail)
                .setPositiveButton("حسناً", null)
                .show();
    }

    private static String fmtSize(long b) {
        if (b <= 0) return "-";
        if (b >= 1048576L) return String.format(Locale.US, "%.1f MB", b / 1048576.0);
        return String.format(Locale.US, "%d KB", b / 1024);
    }

    private static String fmtDate(long t) {
        if (t <= 0) return "-";
        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(t));
    }

    private static long parseLong(String s) {
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return 0; }
    }

    private static long apkSize(ApplicationInfo ai) {
        long size = 0;
        if (ai.sourceDir != null) size += new File(ai.sourceDir).length();
        if (ai.splitSourceDirs != null) {
            for (String s : ai.splitSourceDirs) size += new File(s).length();
        }
        return size;
    }

    private static Bitmap toBitmap(Drawable d, int sz) {
        Bitmap bm = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        Rect old = d.copyBounds();
        d.setBounds(0, 0, sz, sz);
        d.draw(c);
        d.setBounds(old);
        return bm;
    }

    private void loadApps(final boolean quiet) {
        restoreMode = false;
        final int seq = ++loadSeq;
        if (!quiet) log("جاري تحميل التطبيقات...");
        loader.execute(() -> {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> all = pm.getInstalledApplications(0);
            final List<AppItem> list = new ArrayList<>();
            for (ApplicationInfo ai : all) {
                boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                if (system || ai.packageName.equals(getPackageName())) continue;

                AppItem it = new AppItem();
                it.pkg = ai.packageName;
                it.label = String.valueOf(ai.loadLabel(pm));
                it.installed = true;
                it.frozen = !ai.enabled;
                try {
                    it.icon = new BitmapDrawable(getResources(), toBitmap(ai.loadIcon(pm), 96));
                } catch (Throwable t) {
                    it.icon = pm.getDefaultActivityIcon();
                }

                String ver = "-";
                int code = 0;
                long inst = 0, upd = 0;
                try {
                    PackageInfo pi = pm.getPackageInfo(ai.packageName, 0);
                    if (pi.versionName != null) ver = pi.versionName;
                    code = pi.versionCode;
                    inst = pi.firstInstallTime;
                    upd = pi.lastUpdateTime;
                } catch (Exception ignored) { }
                long size = apkSize(ai);
                it.info = "الإصدار " + ver + " • " + fmtSize(size) + " • " + fmtDate(upd)
                        + (it.frozen ? " • مجمّد" : "");
                it.detail = "الاسم: " + it.label + "\n"
                        + "الحزمة: " + it.pkg + "\n"
                        + "الإصدار: " + ver + " (" + code + ")\n"
                        + "حجم التطبيق (APK): " + fmtSize(size) + "\n"
                        + "تاريخ التثبيت: " + fmtDate(inst) + "\n"
                        + "آخر تحديث: " + fmtDate(upd) + "\n"
                        + "الحالة: " + (it.frozen ? "مجمّد" : "مفعّل") + "\n"
                        + "المسار: " + ai.sourceDir;
                list.add(it);
            }
            Collections.sort(list, (a, b) -> a.label.compareToIgnoreCase(b.label));
            runOnUiThread(() -> {
                if (seq != loadSeq) return;
                showItems(list);
                if (!quiet) log("عدد التطبيقات: " + list.size());
            });
        });
    }

    private void loadBackups(final boolean quiet) {
        restoreMode = true;
        final int seq = ++loadSeq;
        if (!quiet) log("جاري قراءة النسخ المحفوظة...");
        loader.execute(() -> {
            RootShell.Result r = RootShell.run(
                    "cd " + BASE + " 2>/dev/null || exit\n" +
                    "for d in *; do\n" +
                    "  [ -d \"$d\" ] || continue\n" +
                    "  echo \"@@PKG=$d\"\n" +
                    "  [ -s \"$d/data.zip\" ] && echo \"HASDATA=1\"\n" +
                    "  [ -f \"$d/info.txt\" ] && cat \"$d/info.txt\"\n" +
                    "  [ -f \"$d/icon.png\" ] && echo \"ICON=$(base64 -w0 \"$d/icon.png\" 2>/dev/null)\"\n" +
                    "done\n");

            PackageManager pm = getPackageManager();
            final List<AppItem> list = new ArrayList<>();
            String curPkg = null;
            Map<String, String> kv = new HashMap<>();
            for (String line : r.out.split("\n")) {
                line = line.trim();
                if (line.startsWith("@@PKG=")) {
                    if (curPkg != null) list.add(buildBackupItem(curPkg, kv, pm));
                    curPkg = line.substring(6);
                    kv = new HashMap<>();
                    if (!curPkg.matches("[A-Za-z0-9_.]+")) curPkg = null;
                } else if (curPkg != null) {
                    int i = line.indexOf('=');
                    if (i > 0) kv.put(line.substring(0, i), line.substring(i + 1));
                }
            }
            if (curPkg != null) list.add(buildBackupItem(curPkg, kv, pm));
            Collections.sort(list, (a, b) -> a.label.compareToIgnoreCase(b.label));

            runOnUiThread(() -> {
                if (seq != loadSeq) return;
                showItems(list);
                if (!quiet) log("عدد النسخ: " + list.size());
            });
        });
    }

    private AppItem buildBackupItem(String pkg, Map<String, String> kv, PackageManager pm) {
        AppItem it = new AppItem();
        it.pkg = pkg;

        String label = kv.get("label");
        Drawable icon = null;
        String b64 = kv.get("ICON");
        if (b64 != null && b64.length() > 0) {
            try {
                byte[] raw = Base64.decode(b64, Base64.DEFAULT);
                Bitmap bm = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                if (bm != null) icon = new BitmapDrawable(getResources(), bm);
            } catch (Exception ignored) { }
        }
        boolean installed = false;
        try {
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            installed = true;
            if (label == null) label = String.valueOf(ai.loadLabel(pm));
            if (icon == null) icon = new BitmapDrawable(getResources(), toBitmap(ai.loadIcon(pm), 96));
        } catch (Throwable ignored) { }
        if (label == null) label = pkg;
        if (icon == null) icon = pm.getDefaultActivityIcon();
        it.label = label;
        it.icon = icon;

        String ver = kv.containsKey("version") ? kv.get("version") : "-";
        String code = kv.containsKey("code") ? kv.get("code") : "-";
        long size = parseLong(kv.containsKey("size") ? kv.get("size") : "0");
        long time = parseLong(kv.containsKey("time") ? kv.get("time") : "0");
        String state = installed ? "مثبت حالياً" : "غير مثبت";
        String data = kv.containsKey("HASDATA") ? "مع البيانات" : "بدون بيانات";
        it.installed = installed;

        if (kv.containsKey("version")) {
            it.info = "الإصدار " + ver + " • " + fmtSize(size) + " • نسخة " + fmtDate(time) + " • " + data + " • " + state;
        } else {
            it.info = "نسخة قديمة بدون معلومات • " + data + " • " + state;
        }
        it.detail = "الاسم: " + label + "\n"
                + "الحزمة: " + pkg + "\n"
                + "الإصدار: " + ver + " (" + code + ")\n"
                + "حجم التطبيق (APK): " + fmtSize(size) + "\n"
                + "تاريخ النسخ: " + fmtDate(time) + "\n"
                + "البيانات: " + data + "\n"
                + "الحالة: " + state + "\n"
                + "المسار: " + BASE + "/" + pkg;
        return it;
    }

    // ---------- التنفيذ ----------

    private void runSelected() {
        final List<String> sel = new ArrayList<>();
        for (AppItem it : allItems) {
            if (selected.contains(it.pkg)) sel.add(it.pkg);
        }
        if (sel.isEmpty()) {
            log("لم تحدد أي تطبيق");
            return;
        }
        runOp(sel, restoreMode ? OP_RESTORE_FULL : OP_BACKUP);
    }

    private void runOp(List<String> sel, int op) {
        if (op == OP_BACKUP_APK || op == OP_RESTORE_APK) {
            startJob(sel, op, new char[0]); // بدون بيانات: لا حاجة لكلمة سر
        } else {
            askPassword(sel, op);
        }
    }

    private void askPassword(final List<String> sel, final int op) {
        final boolean restore = op >= OP_RESTORE_FULL;
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        et.setHint("كلمة السر");
        new AlertDialog.Builder(this)
                .setTitle(restore ? "كلمة سر الاستعادة" : "كلمة سر النسخة")
                .setView(et)
                .setPositiveButton("موافق", (d, w) -> {
                    char[] pass = new char[et.length()];
                    et.getText().getChars(0, pass.length, pass, 0);
                    if (pass.length == 0) {
                        log("كلمة السر فارغة");
                        return;
                    }
                    startJob(sel, op, pass);
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void startJob(final List<String> sel, final int op, final char[] pass) {
        btnRun.setEnabled(false);
        ex.execute(() -> {
            for (String pkg : sel) {
                String res;
                switch (op) {
                    case OP_BACKUP:
                        log("نسخ مع البيانات: " + pkg);
                        res = backupPackage(pkg, pass, true);
                        break;
                    case OP_BACKUP_APK:
                        log("نسخ بدون البيانات: " + pkg);
                        res = backupPackage(pkg, pass, false);
                        break;
                    case OP_RESTORE_APK:
                        log("استعادة التطبيق فقط: " + pkg);
                        res = restorePackage(pkg, pass, true, false);
                        break;
                    case OP_RESTORE_DATA:
                        log("استعادة البيانات: " + pkg);
                        res = restorePackage(pkg, pass, false, true);
                        break;
                    default:
                        log("استعادة: " + pkg);
                        res = restorePackage(pkg, pass, true, true);
                        break;
                }
                log(res);
            }
            Arrays.fill(pass, '\0');
            log("— انتهى —");
            runOnUiThread(() -> {
                btnRun.setEnabled(true);
                reload();
            });
        });
    }

    // ---------- قائمة النقاط الثلاث ----------

    private void showMenu(View anchor, final AppItem it) {
        PopupMenu menu = new PopupMenu(this, anchor);
        Menu m = menu.getMenu();
        if (it.installed) m.add(0, M_LAUNCH, 0, "تشغيل");
        if (!restoreMode) {
            m.add(0, M_STOP, 0, "فرض إيقاف");
            m.add(0, M_BK_DATA, 0, "نسخ احتياطي مع البيانات");
            m.add(0, M_BK_APK, 0, "نسخ احتياطي بدون البيانات");
            m.add(0, M_RS_DATA, 0, "استعادة البيانات");
            m.add(0, M_CLEAR_DATA, 0, "مسح بيانات التطبيق");
            m.add(0, M_CLEAR_CACHE, 0, "مسح الكاش");
            m.add(0, it.frozen ? M_UNFREEZE : M_FREEZE, 0, it.frozen ? "إلغاء التجميد" : "تجميد");
            m.add(0, M_UNINSTALL, 0, "إلغاء التثبيت");
            m.add(0, M_UNINSTALL_KEEP, 0, "إلغاء التثبيت مع إبقاء البيانات");
            m.add(0, M_SETTINGS, 0, "معلومات التطبيق (إعدادات النظام)");
        } else {
            m.add(0, M_RS_FULL, 0, "استعادة التطبيق + البيانات");
            m.add(0, M_RS_APK, 0, "استعادة التطبيق فقط");
            m.add(0, M_RS_DATA, 0, "استعادة البيانات فقط");
            m.add(0, M_DEL_BACKUP, 0, "حذف هذه النسخة");
        }
        m.add(0, M_COPY_PKG, 0, "نسخ اسم الحزمة");
        menu.setOnMenuItemClickListener(mi -> {
            onMenu(mi.getItemId(), it);
            return true;
        });
        menu.show();
    }

    private void onMenu(int id, AppItem it) {
        final String pkg = it.pkg;
        final List<String> one = new ArrayList<>();
        one.add(pkg);
        switch (id) {
            case M_LAUNCH: {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) {
                    log("لا توجد واجهة تشغيل للتطبيق" + (it.frozen ? " (مجمّد)" : ""));
                } else {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try { startActivity(i); } catch (Exception e) { log("تعذر التشغيل: " + e.getMessage()); }
                }
                break;
            }
            case M_STOP:
                rootAction("فرض إيقاف " + pkg, "am force-stop " + pkg, false);
                break;
            case M_BK_DATA:
                runOp(one, OP_BACKUP);
                break;
            case M_BK_APK:
                runOp(one, OP_BACKUP_APK);
                break;
            case M_RS_DATA:
                runOp(one, OP_RESTORE_DATA);
                break;
            case M_RS_FULL:
                runOp(one, OP_RESTORE_FULL);
                break;
            case M_RS_APK:
                runOp(one, OP_RESTORE_APK);
                break;
            case M_CLEAR_DATA:
                confirm("مسح كل بيانات «" + it.label + "»؟ لا يمكن التراجع.",
                        () -> rootAction("مسح بيانات " + pkg, "pm clear " + pkg, false));
                break;
            case M_CLEAR_CACHE:
                rootAction("مسح الكاش " + pkg,
                        "rm -rf /data/data/" + pkg + "/cache/* /data/data/" + pkg + "/code_cache/* "
                                + "/sdcard/Android/data/" + pkg + "/cache/*", false);
                break;
            case M_FREEZE:
                rootAction("تجميد " + pkg, "pm disable-user --user 0 " + pkg, true);
                break;
            case M_UNFREEZE:
                rootAction("إلغاء تجميد " + pkg, "pm enable " + pkg, true);
                break;
            case M_UNINSTALL:
                confirm("إلغاء تثبيت «" + it.label + "»؟ ستُحذف بياناته أيضاً.",
                        () -> rootAction("إلغاء تثبيت " + pkg, "pm uninstall " + pkg, true));
                break;
            case M_UNINSTALL_KEEP:
                confirm("إلغاء تثبيت «" + it.label + "» مع إبقاء بياناته؟",
                        () -> rootAction("إلغاء تثبيت (إبقاء البيانات) " + pkg, "pm uninstall -k " + pkg, true));
                break;
            case M_DEL_BACKUP:
                confirm("حذف نسخة «" + it.label + "» نهائياً؟",
                        () -> rootAction("حذف النسخة " + pkg, "rm -rf " + BASE + "/" + pkg, true));
                break;
            case M_SETTINGS: {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + pkg));
                try { startActivity(i); } catch (Exception e) { log("تعذر الفتح: " + e.getMessage()); }
                break;
            }
            case M_COPY_PKG: {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("package", pkg));
                    log("تم نسخ: " + pkg);
                }
                break;
            }
            default:
                break;
        }
    }

    private void confirm(String msg, final Runnable ok) {
        new AlertDialog.Builder(this)
                .setMessage(msg)
                .setPositiveButton("نعم", (d, w) -> ok.run())
                .setNegativeButton("إلغاء", null)
                .show();
    }

    /** ينفذ أمر روت في الخلفية ويكتب النتيجة في السجل. */
    private void rootAction(final String title, final String cmd, final boolean refresh) {
        ex.execute(() -> {
            RootShell.Result r = RootShell.run(cmd + " 2>&1");
            String o = r.out.trim();
            log(title + ": " + (o.isEmpty() ? "تم" : o));
            if (refresh) runOnUiThread(this::reload);
        });
    }

    // ---------- أدوات ----------

    private static Process su(String cmd) throws IOException {
        return new ProcessBuilder("su", "-c", cmd).redirectErrorStream(false).start();
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
    }

    private static String readAll(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        return sb.toString();
    }

    private static ZipParameters zipParams(String nameInZip) {
        ZipParameters zp = new ZipParameters();
        zp.setFileNameInZip(nameInZip);
        zp.setEncryptFiles(true);
        zp.setEncryptionMethod(EncryptionMethod.AES);
        zp.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);
        return zp;
    }

    private static String parentFor(String entryName) {
        for (String[] s : SRC) if (s[0].equals(entryName)) return s[1];
        return null;
    }

    // ---------- النسخ ----------

    /** مسارات ملفات APK للتطبيق (base + splits) من النظام مباشرة، وإلا عبر pm path. */
    private List<String> apkPaths(String pkg) {
        List<String> out = new ArrayList<>();
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(pkg, 0);
            if (ai.sourceDir != null) out.add(ai.sourceDir);
            if (ai.splitSourceDirs != null) out.addAll(Arrays.asList(ai.splitSourceDirs));
        } catch (Exception ignored) { }
        if (out.isEmpty()) {
            RootShell.Result r = RootShell.run("pm path " + pkg);
            for (String line : r.out.split("\n")) {
                line = line.trim();
                if (line.startsWith("package:")) out.add(line.substring(8));
            }
        }
        return out;
    }

    private static String sizeOf(String path) {
        RootShell.Result r = RootShell.run("stat -c %s '" + path + "' 2>/dev/null");
        return r.out.trim();
    }

    /** ينسخ ملفات APK إلى مجلد النسخة. يرجع null عند النجاح أو رسالة الخطأ. */
    private String backupApks(String pkg, String b) {
        List<String> srcs = apkPaths(pkg);
        if (srcs.isEmpty()) return "لم يتم العثور على مسار ملفات APK";
        StringBuilder err = new StringBuilder();
        int ok = 0;
        for (String src : srcs) {
            String dst = b + "/" + new java.io.File(src).getName();
            String want = sizeOf(src);
            boolean done = false;
            // الطريقة 1: cat (نفس طريقة كتابة data.zip التي تعمل)، ثم cp، ثم dd
            String[] cmds = {
                    "cat '" + src + "' > '" + dst + "'",
                    "cp '" + src + "' '" + dst + "'",
                    "dd if='" + src + "' of='" + dst + "' bs=1048576"
            };
            for (String c : cmds) {
                RootShell.Result r = RootShell.run(c + " 2>&1");
                String got = sizeOf(dst);
                if (want.length() > 0 && want.equals(got)) {
                    RootShell.run("chmod 644 '" + dst + "'");
                    log("  APK: " + new java.io.File(src).getName() + " (" + got + " بايت)");
                    done = true;
                    break;
                }
                err.append("  [").append(c.split(" ")[0]).append("] ").append(r.out.trim())
                        .append(" (حجم المصدر=").append(want).append(" الناتج=").append(got).append(")\n");
            }
            if (done) ok++;
        }
        if (ok == srcs.size()) return null;
        return "نجح نسخ " + ok + " من " + srcs.size() + " ملف APK\n" + err;
    }

    private static boolean writeRoot(String path, byte[] data) {
        try {
            Process p = new ProcessBuilder("su", "-c", "cat > '" + path + "'")
                    .redirectErrorStream(true).start();
            OutputStream o = p.getOutputStream();
            o.write(data);
            o.close();
            copy(p.getInputStream(), new ByteArrayOutputStream());
            return p.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** يحفظ info.txt و icon.png بجانب النسخة (غير حرجة: الفشل لا يوقف النسخ). */
    private void writeMeta(String pkg, String b) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            PackageInfo pi = pm.getPackageInfo(pkg, 0);
            String label = String.valueOf(ai.loadLabel(pm)).replace('\n', ' ').replace('\r', ' ');
            String ver = pi.versionName == null ? "-" : pi.versionName.replace('\n', ' ').replace('\r', ' ');
            String txt = "label=" + label + "\n"
                    + "version=" + ver + "\n"
                    + "code=" + pi.versionCode + "\n"
                    + "size=" + apkSize(ai) + "\n"
                    + "time=" + System.currentTimeMillis() + "\n";
            writeRoot(b + "/info.txt", txt.getBytes("UTF-8"));

            Bitmap bm = toBitmap(pm.getApplicationIcon(pkg), 96);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.PNG, 100, bo);
            writeRoot(b + "/icon.png", bo.toByteArray());
        } catch (Throwable ignored) { }
    }

    private String backupPackage(String pkg, char[] pass, boolean withData) {
        String b = BASE + "/" + pkg;
        // 1) ملفات APK (غير مشفرة)
        if (withData) {
            RootShell.run("mkdir -p " + b + " && rm -rf " + b + "/*");
        } else {
            // بدون بيانات: لا نمس data.zip الموجود من نسخة سابقة
            RootShell.run("mkdir -p " + b + " && rm -f " + b + "/*.apk " + b + "/info.txt " + b + "/icon.png");
        }
        String apkErr = backupApks(pkg, b);
        if (apkErr != null) return "  ✘ فشل نسخ التطبيق (APK): " + apkErr;
        writeMeta(pkg, b); // الأيقونة ومعلومات التطبيق لعرضها في قائمة النسخ
        if (!withData) return "  ✔ تم (التطبيق فقط بدون بيانات)";

        // 2) البيانات: tar يُمرَّر مباشرة إلى zip مشفر AES-256 (بدون ملفات مؤقتة)
        boolean gotData = false;
        ZipOutputStream zos = null;
        Process writer = null;
        try {
            writer = new ProcessBuilder("su", "-c", "cat > " + b + "/data.zip")
                    .redirectErrorStream(true).start();
            zos = new ZipOutputStream(writer.getOutputStream(), pass);

            for (String[] s : SRC) {
                String dir = s[1] + "/" + pkg;
                String chk = RootShell.run("[ -d " + dir + " ] && echo YES").out;
                if (!chk.contains("YES")) continue;

                String excl = s[0].equals("data.tar")
                        ? " --exclude=" + pkg + "/cache --exclude=" + pkg + "/code_cache" : "";
                Process t = su("tar -C " + s[1] + excl + " -cf - " + pkg + " 2>/dev/null");
                zos.putNextEntry(zipParams(s[0]));
                copy(t.getInputStream(), zos);
                zos.closeEntry();
                t.waitFor();
                if (s[0].equals("data.tar")) gotData = true;
            }
            zos.close();
            zos = null;
            writer.waitFor();
        } catch (Exception e) {
            try { if (zos != null) zos.close(); } catch (Exception ignored) { }
            return "  ✘ فشل: " + e;
        }

        if (!gotData) return "  ✘ فشل: لم يتم العثور على مجلد بيانات التطبيق";

        RootShell.Result r = RootShell.run(
                "B=" + b + "\n" +
                "ls $B/*.apk >/dev/null 2>&1 && [ -s $B/data.zip ] && echo RESULT_OK\n");
        return r.out.contains("RESULT_OK") ? "  ✔ تم (مشفر)" : "  ✘ فشل في التحقق من الملفات";
    }

    // ---------- الاستعادة ----------

    /** تثبيت جلسة (يدعم الـsplits) ثم install-multiple ثم install. يرجع true عند النجاح. */
    private boolean installSession(List<String> files, String tmp, StringBuilder log) {
        long total = 0;
        for (String f : files) {
            try { total += Long.parseLong(sizeOf(tmp + "/" + f)); } catch (Exception ignored) { }
        }
        RootShell.Result c = RootShell.run("pm install-create -r -d -S " + total + " </dev/null 2>&1");
        Matcher m = Pattern.compile("\\[(\\d+)\\]").matcher(c.out);
        if (m.find()) {
            String sid = m.group(1);
            boolean ok = true;
            for (String f : files) {
                String sz = sizeOf(tmp + "/" + f);
                RootShell.Result w = RootShell.run("pm install-write -S " + sz + " " + sid
                        + " '" + f + "' '" + tmp + "/" + f + "' </dev/null 2>&1");
                if (!w.out.contains("Success")) { ok = false; log.append(w.out); break; }
            }
            if (ok) {
                RootShell.Result k = RootShell.run("pm install-commit " + sid + " </dev/null 2>&1");
                if (k.out.contains("Success")) return true;
                log.append(k.out);
            } else {
                RootShell.run("pm install-abandon " + sid + " </dev/null 2>&1");
            }
        } else {
            log.append(c.out);
        }

        StringBuilder all = new StringBuilder();
        for (String f : files) all.append(" '").append(tmp).append("/").append(f).append("'");
        RootShell.Result r = RootShell.run("pm install-multiple -r -d" + all + " </dev/null 2>&1");
        if (r.out.contains("Success")) return true;
        log.append(r.out);
        if (files.size() == 1) {
            r = RootShell.run("pm install -r -d" + all + " </dev/null 2>&1");
            if (r.out.contains("Success")) return true;
            log.append(r.out);
        }
        return false;
    }

    /** ينسخ APK من النسخة إلى مجلد مؤقت ثم يثبتها. 1 نجح، 0 لا يوجد APK، -1 فشل. */
    private int installApks(String pkg, String b, String tmp, StringBuilder log) {
        RootShell.run("rm -rf " + tmp + "; mkdir -p " + tmp);
        RootShell.Result ls = RootShell.run("ls -1 " + b);
        List<String> files = new ArrayList<>();
        for (String line : ls.out.split("\n")) {
            line = line.trim();
            if (line.endsWith(".apk")) files.add(line);
        }
        if (files.isEmpty()) {
            RootShell.run("rm -rf " + tmp);
            return 0;
        }
        for (String f : files) {
            String dst = tmp + "/" + f;
            RootShell.run("cat '" + b + "/" + f + "' > '" + dst + "'; chmod 644 '" + dst + "'; "
                    + "chcon u:object_r:shell_data_file:s0 '" + dst + "' 2>/dev/null");
        }
        boolean ok = installSession(files, tmp, log);
        if (!ok && log.toString().contains("INSTALL_FAILED_UPDATE_INCOMPATIBLE")) {
            // توقيع مختلف عن النسخة المثبتة: تُحذف ثم تُثبَّت (البيانات ستُستعاد بعدها)
            log.append("  توقيع مختلف: حذف النسخة الحالية وإعادة التثبيت\n");
            RootShell.run("pm uninstall " + pkg + " </dev/null 2>&1");
            ok = installSession(files, tmp, log);
        }
        RootShell.run("rm -rf " + tmp);
        return ok ? 1 : -1;
    }

    private String restorePackage(String pkg, char[] pass, boolean doApk, boolean doData) {
        String b = BASE + "/" + pkg;
        String tmp = "/data/local/tmp/rs_" + pkg;

        String noDataNote = "";
        if (doData) {
            boolean hasData = RootShell.run("[ -s " + b + "/data.zip ] && echo YES").out.contains("YES");
            if (!hasData) {
                if (!doApk) return "  ✘ لا توجد بيانات محفوظة لهذا التطبيق";
                doData = false;
                noDataNote = "  ⚠ النسخة بدون بيانات: تم الاكتفاء بالتطبيق\n";
            }
        }
        if (!doData) {
            // استعادة التطبيق فقط
            StringBuilder ilog = new StringBuilder();
            int ir = installApks(pkg, b, tmp, ilog);
            if (ir == 1) return noDataNote + "  ✔ تم تثبيت التطبيق";
            if (ir == 0) return "  ✘ لا توجد ملفات APK في النسخة";
            return "  ✘ فشل تثبيت التطبيق:\n" + ilog;
        }

        ZipInputStream zis = null;
        try {
            Process rd = su("cat " + b + "/data.zip");
            zis = new ZipInputStream(rd.getInputStream(), pass);

            // قراءة أول ملف تتحقق من كلمة السر قبل أي تعديل على التطبيق
            LocalFileHeader h = zis.getNextEntry();
            if (h == null) return "  ✘ ملف data.zip غير موجود أو فارغ";

            // تثبيت التطبيق بطريقة التطبيقات العادية (جلسة تثبيت)، ثم إيجاد UID
            StringBuilder ilog = new StringBuilder();
            int ir = doApk ? installApks(pkg, b, tmp, ilog) : 2; // 1 نجح، 0 لا يوجد APK، -1 فشل، 2 تخطي
            RootShell.Result pr = RootShell.run(
                    "am force-stop " + pkg + "\n" +
                    "echo UID=$(stat -c %u /data/data/" + pkg + " 2>/dev/null)\n");
            Matcher m = Pattern.compile("UID=(\\d+)").matcher(pr.out);
            if (!m.find()) {
                return doApk ? "  ✘ التطبيق غير مثبت وفشل تثبيته:\n" + ilog
                        : "  ✘ التطبيق غير مثبت: ثبّته أولاً (استعادة التطبيق + البيانات)";
            }
            String uid = m.group(1);
            String installNote;
            if (ir == 2) {
                installNote = "";
            } else if (ir == 1) {
                installNote = "  ✔ تم تثبيت التطبيق\n";
            } else if (ir == 0) {
                installNote = "  ⚠ لا توجد ملفات APK في النسخة، تم الاكتفاء بالبيانات\n";
            } else {
                installNote = "  ⚠ تعذر تثبيت APK (سيتم استعادة البيانات للتطبيق الموجود):\n" + ilog + "\n";
            }

            StringBuilder report = new StringBuilder();
            while (h != null) {
                String name = h.getFileName();
                String parent = parentFor(name);
                if (parent != null) {
                    String dir = parent + "/" + pkg;
                    String prep = "mkdir -p " + parent + "\n";
                    if (name.equals("data.tar") || name.equals("user_de.tar")) {
                        prep += "rm -rf " + dir + "/* " + dir + "/.[!.]*\n";
                    }
                    RootShell.run(prep);

                    Process t = new ProcessBuilder("su", "-c", "tar -xf - -C " + parent + " 2>&1")
                            .redirectErrorStream(true).start();
                    OutputStream o = t.getOutputStream();
                    copy(zis, o);
                    o.close();
                    report.append(readAll(t.getInputStream()));
                    t.waitFor();

                    if (name.equals("data.tar") || name.equals("user_de.tar")) {
                        RootShell.run(
                                "chown -R " + uid + ":" + uid + " " + dir + "\n" +
                                "restorecon -R " + dir + "\n");
                    }
                } else {
                    copy(zis, new java.io.ByteArrayOutputStream()); // تجاهل ملف غير معروف
                }
                h = zis.getNextEntry();
            }
            zis.close();
            zis = null;
            return installNote + "  ✔ تم\n" + report;
        } catch (ZipException e) {
            if (e.getType() == ZipException.Type.WRONG_PASSWORD) {
                return "  ✘ كلمة السر خاطئة (لم يتم تعديل أي شيء)";
            }
            return "  ✘ فشل: " + e.getMessage();
        } catch (Exception e) {
            return "  ✘ فشل: " + e;
        } finally {
            try { if (zis != null) zis.close(); } catch (Exception ignored) { }
        }
    }

    private void log(final String s) {
        runOnUiThread(() -> {
            txtLog.append(s + "\n");
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        });
    }
}
