package com.example.mystery;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStreamReader;

/** تنفيذ أوامر بصلاحية الروت عبر su، مع تجربة كل المسارات المعروفة. */
public class RootShell {

    public static class Result {
        public int code;
        public String out;
    }

    private static final String[] CANDIDATES = {
            "su",
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/debug_ramdisk/su",
            "/data/adb/magisk/su",
            "/data/adb/ksu/bin/su",
            "/data/adb/ap/bin/su",
            "/data/adb/ksud",          // يُستخدم كـ: ksud su
            "/su/bin/su",
            "/vendor/bin/su",
            "/product/bin/su"
    };

    private static String suPath = null;
    public static String lastError = "";

    /** يرجع أمر التشغيل الصالح أو null. */
    private static synchronized String[] findSu() {
        if (suPath != null) return build(suPath);
        for (String c : CANDIDATES) {
            if (!c.equals("su") && !new File(c).exists()) continue;
            try {
                Process p = new ProcessBuilder(build(c)).redirectErrorStream(true).start();
                DataOutputStream os = new DataOutputStream(p.getOutputStream());
                os.write("id\nexit\n".getBytes("UTF-8"));
                os.flush();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String l;
                while ((l = br.readLine()) != null) sb.append(l).append('\n');
                p.waitFor();
                if (sb.toString().contains("uid=0")) {
                    suPath = c;
                    return build(c);
                } else {
                    lastError = c + " -> " + sb.toString().trim();
                }
            } catch (Exception e) {
                lastError = c + " -> " + e.getMessage();
            }
        }
        return null;
    }

    private static String[] build(String c) {
        if (c.equals("/data/adb/ksud")) return new String[]{c, "su"};
        return new String[]{c};
    }

    public static String foundPath() {
        return suPath;
    }

    public static Result run(String cmd) {
        Result r = new Result();
        StringBuilder sb = new StringBuilder();
        String[] su = findSu();
        if (su == null) {
            r.code = -1;
            r.out = "لا يوجد su صالح. آخر خطأ: " + lastError + "\n";
            return r;
        }
        try {
            Process p = new ProcessBuilder(su).redirectErrorStream(true).start();
            DataOutputStream os = new DataOutputStream(p.getOutputStream());
            os.write((cmd + "\nexit\n").getBytes("UTF-8"));
            os.flush();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
            r.code = p.waitFor();
        } catch (Exception e) {
            r.code = -1;
            sb.append("EXC: ").append(e.getMessage()).append('\n');
        }
        r.out = sb.toString();
        return r;
    }

    public static boolean hasRoot() {
        return findSu() != null;
    }
}
